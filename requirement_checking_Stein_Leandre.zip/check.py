from case3_checker import Case3Checker
from case4_checker import Case4Checker

from charstream import CharacterStream

print("Verifying case 3...")
with open('trace.txt', 'r') as myfile:
    data=myfile.read()
a = CharacterStream(data)
case3test = Case3Checker(a)
if case3test.scan():
    print("Case 3 validated correctly")
else:
    print("Error found in case 3")

print("\nVerifying case 4...")
with open('trace.txt', 'r') as myfile:
    data=myfile.read()
a = CharacterStream(data)
case4test = Case4Checker(a)
if case4test.scan():
    print("Case 4 validated correctly")
else:
    print("Error found in case 4")
